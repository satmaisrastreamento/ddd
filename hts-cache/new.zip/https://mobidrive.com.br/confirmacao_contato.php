  <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
	<script src="https://kit.fontawesome.com/a132241e15.js"></script>
    <title>Mobi Drive Rastreamento Veicular</title>

    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/style.css" rel="stylesheet">
</head>
<body id="page-top" class="landing-page no-skin-config">
<div class="navbar-wrapper">
        <nav class="navbar navbar-default navbar-fixed-top navbar-expand-md" role="navigation">
            <div class="container">
                <img src="img/logo.png">
                <div class="navbar-header page-scroll">
                    <button class="navbar-toggler btn-danger" type="button" data-toggle="collapse" data-target="#navbar">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
                <div class="collapse navbar-collapse justify-content-end" id="navbar">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="nav-link page-scroll" href="index.php#page-top"><span style="color:#000">Início</span></a></li>
                        <li><a class="nav-link page-scroll" href="index.php#features"><span style="color:#000">Características</span></a></li>
                        <li><a class="nav-link page-scroll" href="index.php#team"><span style="color:#000">Empresa</a></li>
                        <li><a class="nav-link page-scroll" href="index.php#testimonials"><span style="color:#000">Comentários</span></a></li>
                        <li><a class="nav-link page-scroll" href="index.php#pricing"><span style="color:#000">Preços</span></a></li>
						<li><a class="nav-link page-scroll" href="http://mobitracker.com.br/boletos/"><span style="color:#000">Boletos</span></a></li>
                        <li><a class="nav-link page-scroll" href="contato.php"><span style="color:#000">Contato</span></a></li>
                    </ul>
                </div>
            </div>
        </nav>
</div>




<form action="" method="post">
<section class="container features">
<br><br><br><br><br><br>
	<div class="row">
	   <div class="col-md-12 text-center">
				<h1 style="color:#000"><b>MENSAGEM ENVIADA</b></h1><br>
				<span style="color:#000">Sua mensagem foi enviada. Responderemos o mais breve possível.<br><br>
				Qualquer dúvida estamos a disposição pelos canais abaixo: </span><br>
				<span style="color:#000"><i class="fas fa-phone"></i> SAC: (51) 2626.4213</span><br>
				<span style="color:#000"><i class="fas fa-phone"></i> Central de Emergência:0800 051 0051</span><br>
				<span style="color:#000"><i class="far fa-envelope-open"></i> E-mail: atendimento@mobidrive.com.br</span><br>
				<span style="color:#000"><i class="fab fa-whatsapp"></i> Whatsapp: (51) 99400.9470</span>
		</div>
	</div>
    
</section>
</form>
<br><br><br><br><br>











<section id="contact" class="gray-section contact">
    <div class="container">
        <div class="row m-b-lg">
            <div class="col-lg-12 text-center">
                <div class="navy-line"></div>
                <h1>Contato</h1>
               
            </div>
        </div>
        <div class="row m-b-lg text-center">
            <div class="col-lg-12">
                
                    <strong><span style="color:#99000; font-size:20px">MOBI DRIVE RASTREAMENTO VEICULAR.</span></strong><br/>
                    <span style="color:#99000; font-size:16px">(51) 2626.4213</span><br/>
                    <span style="color:#99000; font-size:16px">0800 051 0051</span><br/>
                    
               
            </div>
            
        </div>
        <div class="row">
            <div class="col-lg-12 text-center">
               
                <p class="m-t-sm">
                    Visite nossas redes sociais
                </p>
                <ul class="list-inline social-icon">
                    <li class="list-inline-item"><a href="https://www.instagram.com/mobidrive.rs" target="_blank"><i class="fa fa-instagram"></i></a>
                    </li>
                    <li class="list-inline-item"><a href="https://www.facebook.com/mobidrivers" target="_blank"><i class="fa fa-facebook"></i></a>
                    
                </ul>
            </div>
        </div>
        <div class="row">
            <div class="col-lg-12 text-center m-t-lg m-b-lg">
                <p><strong>&copy; 2015 Mobi Drive</strong><br/></p>
            </div>
        </div>
    </div>
</section>

<!-- Mainly scripts -->
<script src="js/jquery-3.1.1.min.js"></script>
<script src="js/popper.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/plugins/slimscroll/jquery.slimscroll.min.js"></script>

<!-- Custom and plugin javascript -->
<script src="js/inspinia.js"></script>
<script src="js/plugins/pace/pace.min.js"></script>
<script src="js/plugins/wow/wow.min.js"></script>


<script>

    $(document).ready(function () {

        $('body').scrollspy({
            target: '#navbar',
            offset: 80
        });

        // Page scrolling feature
        $('a.page-scroll').bind('click', function(event) {
            var link = $(this);
            $('html, body').stop().animate({
                scrollTop: $(link.attr('href')).offset().top - 50
            }, 500);
            event.preventDefault();
            $("#navbar").collapse('hide');
        });
    });

    var cbpAnimatedHeader = (function() {
        var docElem = document.documentElement,
                header = document.querySelector( '.navbar-default' ),
                didScroll = false,
                changeHeaderOn = 200;
        function init() {
            window.addEventListener( 'scroll', function( event ) {
                if( !didScroll ) {
                    didScroll = true;
                    setTimeout( scrollPage, 250 );
                }
            }, false );
        }
        function scrollPage() {
            var sy = scrollY();
            if ( sy >= changeHeaderOn ) {
                $(header).addClass('navbar-scroll')
            }
            else {
                $(header).removeClass('navbar-scroll')
            }
            didScroll = false;
        }
        function scrollY() {
            return window.pageYOffset || docElem.scrollTop;
        }
        init();

    })();

    // Activate WOW.js plugin for animation on scrol
    new WOW().init();

</script>
	<script>
			$(document).on('submit', 'form', function (e) {
				e.preventDefault();
				//Receber os dados
				$form = $(this);				
				var formdata = new FormData($form[0]);
				
				//Criar a conexao com o servidor
				var request = new XMLHttpRequest();
				
				//Progresso do Upload
				request.upload.addEventListener('progress', function (e) {
					var percent = Math.round(e.loaded / e.total * 100);
					$form.find('.progress-bar').width(percent + '%').html(percent + '%');
				});
				
				//Upload completo limpar a barra de progresso
				request.addEventListener('load', function(e){
					$form.find('.progress-bar').addClass('progress-bar-success').html('Mensagem enviada com sucesso. Aguarde...');
					//Atualizar a página após o upload completo
					var i = setInterval(function() {
   					clearInterval(i);
					top.location = 'confirmacao_contato.php';
					}, 1000);
	
				
				});
				

				//Arquivo responsável em fazer o upload da imagem
				request.open('post', 'enviar_contato.php');
				request.send(formdata);
			});
			

			
		</script>
</body>
</html>
